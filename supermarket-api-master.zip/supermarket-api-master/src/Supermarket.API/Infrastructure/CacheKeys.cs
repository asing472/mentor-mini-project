namespace Supermarket.API.Infrastructure
{
    public enum CacheKeys : byte
    {
        CategoriesList,
        ProductsList,
    }
}